const path = require('path');

module.exports = {
  mode: 'production',
  entry: './src/index.js', // Ensure this path is correct
  output: {
    filename: 'bundle.js',
    path: path.resolve(__dirname, 'dist')
  },
  // Additional configurations...
};

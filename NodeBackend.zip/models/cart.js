
// const mongoose=require('mongoose')

// const cartSchema=new mongoose.Schema({
//     _id:mongoose.Schema.Types.ObjectId,
//     name: { type: String, required: false, maxlength: 50 },
//     price: { type: Number, required: false, maxlength: 50 },
//     description:{ type: String, required: false, maxlength: 50 },
//     countInStock:{ type: Number, required: false, maxlength: 50 },
  
   
//     imageUrl: { type: String, required: false, maxlength: 50 },
// })
// module.exports=mongoose.model('Cart',cartSchema)
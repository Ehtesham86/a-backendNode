const { expect } = require('chai');

describe('Sample Test', () => {
  it('should pass this test', () => {
    expect(true).to.be.true;
  });
});
